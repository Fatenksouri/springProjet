# springProjet
Premier pas dans l'univers de Spring, ce projet académique vise à acquérir les bases fondamentales du Framework Spring
