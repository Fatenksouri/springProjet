package tn.esprit.tic.sprinprojet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprinProjetApplication {

    public static void main(String[] args) {
        SpringApplication.run(SprinProjetApplication.class, args);
    }

}
