package tn.esprit.tic.sprinprojet.Entity;

public enum Typec {
    SIMPLE,
    Double,
    TRIPLE;
}
